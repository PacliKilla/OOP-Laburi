package com.company.lab;

public class Monitor {
    String color = "Blue";
    float height = 39.2f;
    float depth = 12.8f;
    float width = 48.5f;
    String resolution = "1900x1090";


}

