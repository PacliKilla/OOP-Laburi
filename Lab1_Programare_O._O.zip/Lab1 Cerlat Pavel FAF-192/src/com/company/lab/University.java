package com.company.lab;

public class University {
    String name;
    int foundationYear;

    public University(String name, int foundationYear) {
        this.name = name;
        this.foundationYear = foundationYear;
    }
}
